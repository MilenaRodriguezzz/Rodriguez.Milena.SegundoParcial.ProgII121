
package parcialbiblioteca;

//Milena Rodríguez, 121

public interface CSVSerializable {
    String toCSV();
}