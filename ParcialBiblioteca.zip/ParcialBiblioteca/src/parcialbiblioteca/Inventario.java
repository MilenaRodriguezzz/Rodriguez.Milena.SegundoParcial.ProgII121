package parcialbiblioteca;

//Milena Rodríguez, 121


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import java.util.Comparator;

public class Inventario<T extends Serializable> {
    private List<T> items = new ArrayList<>();

    public void agregar(T item) {
        items.add(item);
    }

    public T obtener(int index) {
        return items.get(index);
    }

    public void eliminar(int index) {
        items.remove(index);
    }

    public List<T> filtrar(Predicate<T> criterio) {
        List<T> filtrados = new ArrayList<>();
        for (T item : items) {
            if (criterio.test(item)) {
                filtrados.add(item);
            }
        }
        return filtrados;
    }

    public void ordenar() {
        items.sort(null);
    }

    public void ordenar(Comparator<T> comparator) {
        items.sort(comparator);
    }

    public void paraCadaElemento(java.util.function.Consumer<T> accion) {
        for (T item : items) {
            accion.accept(item);
        }
    }

    public void guardarEnArchivo(String path) throws IOException {
        try (ObjectOutputStream output = new ObjectOutputStream(new FileOutputStream(path))) {
            output.writeObject(items);
        }
    }

    public void cargarDesdeArchivo(String path) throws IOException, ClassNotFoundException {
        try (ObjectInputStream input = new ObjectInputStream(new FileInputStream(path))) {
            items = (List<T>) input.readObject();
        }
    }

    public void guardarEnCSV(String path) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(path))) {
            for (T item : items) {
                if (item instanceof Libro) {
                    writer.write(((Libro) item).toCSV());
                    writer.newLine();
                }
            }
        }
    }

    public void cargarDesdeCSV(String path) throws IOException {
        try (BufferedReader bf = new BufferedReader(new FileReader(path))) {
            String linea;
            while ((linea = bf.readLine()) != null) {
                if (linea.endsWith("\n")) {
                    linea = linea.substring(0, linea.length() - 1);
                }
                String[] data = linea.split(",");
                if (data.length == 4) {
                    try {
                        int id = Integer.parseInt(data[0]);
                        String titulo = data[1];
                        String autor = data[2];
                        Categoria categoria = Categoria.valueOf(data[3].toUpperCase());
                        Libro libro = new Libro(id, titulo, autor, categoria);
                        items.add((T) libro);
                    } catch (IllegalArgumentException e) {
                        System.err.println("Error al parsear la línea: " + linea + " - " + e.getMessage());
                    }
                } else {
                    System.err.println("Línea con formato incorrecto: " + linea);
                }
            }
        }
    }

    public void serializarLibros(String path) throws IOException {
        try (ObjectOutputStream output = new ObjectOutputStream(new FileOutputStream(path))) {
            output.writeObject(items);
        }
    }

    public void deserializarLibros(String path) throws IOException, ClassNotFoundException {
        try (ObjectInputStream input = new ObjectInputStream(new FileInputStream(path))) {
            items = (List<T>) input.readObject();
        }
    }
}



    

