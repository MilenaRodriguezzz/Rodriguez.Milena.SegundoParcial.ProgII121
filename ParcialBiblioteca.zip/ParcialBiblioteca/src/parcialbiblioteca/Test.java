package parcialbiblioteca;

//Milena Rodríguez, 121

import java.io.IOException;

public class Test {
    public static void main(String[] args) { 
    try { 
        Inventario<Libro> inventarioLibros = new Inventario<>();  
        inventarioLibros.agregar(new Libro(1, "1984", "George Orwell", Categoria.ENTRETENIMIENTO)); 
        inventarioLibros.agregar(new Libro(2, "El señor de los anillos", "J.R.R. Tolkien", Categoria.LITERATURA)); 
        inventarioLibros.agregar(new Libro(3, "Cien años de soledad", "Gabriel García Márquez", Categoria.LITERATURA)); 
        inventarioLibros.agregar(new Libro(4, "El origen de las especies", "Charles Darwin", Categoria.CIENCIA)); 
        inventarioLibros.agregar(new Libro(5, "La guerra de los mundos", "H.G. Wells", Categoria.ENTRETENIMIENTO)); 
 

        System.out.println("Inventario de libros:"); 
        inventarioLibros.paraCadaElemento(libro -> System.out.println(libro)); 
 

        System.out.println("\nLibros de la categoría LITERATURA:"); 
        inventarioLibros.filtrar(libro -> libro.getCategoria() == Categoria.LITERATURA) 
                        .forEach(libro -> System.out.println(libro)); 
 

        System.out.println("\nLibros cuyo título contiene '1984':"); 
        inventarioLibros.filtrar(libro -> libro.getTitulo().contains("1984")) 
                        .forEach(libro -> System.out.println(libro)); 
 

        System.out.println("\nLibros ordenados de manera natural (por id):"); 
        inventarioLibros.ordenar(); 
        inventarioLibros.paraCadaElemento(libro -> System.out.println(libro)); 
 

        System.out.println("\nLibros ordenados por título:"); 
        inventarioLibros.ordenar((libro1, libro2) -> libro1.getTitulo().compareTo(libro2.getTitulo())); 
        inventarioLibros.paraCadaElemento(libro -> System.out.println(libro)); 
 

        inventarioLibros.guardarEnArchivo("src/data/libros.dat"); 
 

        Inventario<Libro> inventarioCargado = new Inventario<>(); 
        inventarioCargado.cargarDesdeArchivo("src/data/libros.dat"); 
        System.out.println("\nLibros cargados desde archivo binario:"); 
        inventarioCargado.paraCadaElemento(libro -> System.out.println(libro)); 
 
        System.out.println("\nLibros cargados desde archivo CSV:"); 
        inventarioCargado.paraCadaElemento(libro -> System.out.println(libro)); 
 
        } catch (IOException | ClassNotFoundException e) { 
            System.err.println("Error: " + e.getMessage()); 
        }
}
}



